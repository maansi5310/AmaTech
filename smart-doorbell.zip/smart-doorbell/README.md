# 🔔 Smart Doorbell

A Wi-Fi doorbell with remote unlock, motion alerts and visitor history.

```
 ESP32 (C)  ──HTTP──▶  Flask API (Python) ──▶ SQLite (SQL)
  button, PIR,            │
  relay, buzzer           ├──▶ Web dashboard (HTML + CSS)
                          └──▶ Android app (Kotlin)
```

## How it works
1. Visitor presses the button → ESP32 beeps and `POST /api/ring`.
2. Server logs the event. If an RFID tag belongs to a **trusted** visitor, the door unlocks automatically.
3. Otherwise the dashboard and the phone show **Unlock / Deny**.
4. Your choice is queued as a command; the ESP32 polls every 2 s and fires the relay for 5 s.
5. PIR sensor logs motion events (30 s cooldown).

## Folder layout
| Folder | Language | What it is |
|---|---|---|
| `firmware/` | C (ESP-IDF) | ESP32 code |
| `backend/` | Python | Flask REST API + `test_api.py` |
| `database/` | SQL | Schema, demo visitors, analytics queries |
| `web/` | HTML + CSS | Live dashboard |
| `android/` | Kotlin | Phone app (Jetpack Compose) |

## Run the backend (try this first, no hardware needed)
```bash
cd backend
pip install -r requirements.txt
python test_api.py        # optional self-test
python app.py             # http://localhost:5000
```
Open the dashboard and enter the API key (default `hackathon-secret`; change with `DOORBELL_API_KEY`).

Simulate a doorbell press without hardware:
```bash
curl -X POST localhost:5000/api/ring -H "X-API-Key: hackathon-secret" \
     -H "Content-Type: application/json" -d '{"device_id":"door-1"}'
```

## Flash the ESP32
1. Edit `WIFI_SSID`, `WIFI_PASS`, `SERVER_URL` (your PC's LAN IP) in `firmware/main/main.c`.
2. `cd firmware && idf.py set-target esp32 && idf.py build flash monitor`

Wiring: button GPIO4→GND, PIR OUT→GPIO27, relay IN→GPIO26, buzzer→GPIO25.

## Android app
Create an *Empty Activity (Compose)* project with package `com.example.smartdoorbell`, copy the two `.kt` files over,
merge `AndroidManifest.snippet.xml`, and set `ApiClient.baseUrl` to your PC's IP (emulator: `http://10.0.2.2:5000`).

## API
| Method | Path | Used by |
|---|---|---|
| POST | `/api/ring` | ESP32 |
| POST | `/api/motion` | ESP32 |
| GET | `/api/commands/<device>` | ESP32 (polling) |
| GET | `/api/events` | Dashboard, app |
| POST | `/api/events/<id>/respond` `{action: unlock\|deny}` | Dashboard, app |
| GET | `/api/stats`, `/api/visitors` | Dashboard |

## Ideas to extend during the hackathon
- MFRC522 RFID reader (hook is ready: `read_rfid_tag()` in `main.c`)
- ESP32-CAM snapshot on each ring, shown in the dashboard
- Face recognition on the server (OpenCV) to fill `visitor_id` automatically
- Two-way voice or preset replies ("Leave it at the door")
- Use HTTPS + per-device keys before any real deployment
