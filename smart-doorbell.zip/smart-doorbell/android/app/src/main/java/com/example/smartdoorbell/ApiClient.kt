package com.example.smartdoorbell

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class DoorEvent(
    val id: Int,
    val ts: String,
    val type: String,
    val status: String,
    val visitor: String?
)

/** Minimal REST client - no external libraries needed. Call from a background coroutine. */
object ApiClient {
    // Use your PC's LAN IP (emulator -> http://10.0.2.2:5000)
    var baseUrl = "http://192.168.1.50:5000"
    var apiKey = "hackathon-secret"

    private fun request(method: String, path: String, body: String? = null): JSONObject {
        val conn = URL(baseUrl + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.setRequestProperty("X-API-Key", apiKey)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray()) }
            }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            return JSONObject(stream.bufferedReader().use { it.readText() })
        } finally {
            conn.disconnect()
        }
    }

    fun getEvents(): List<DoorEvent> {
        val arr = request("GET", "/api/events?limit=30").getJSONArray("events")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            DoorEvent(
                id = o.getInt("id"),
                ts = o.getString("ts"),
                type = o.getString("type"),
                status = o.getString("status"),
                visitor = if (o.isNull("visitor")) null else o.getString("visitor")
            )
        }
    }

    fun respond(eventId: Int, action: String) {
        request("POST", "/api/events/$eventId/respond", """{"action":"$action"}""")
    }
}
