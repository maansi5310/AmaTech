package com.example.smartdoorbell

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val CHANNEL_ID = "doorbell"

class MainActivity : ComponentActivity() {

    private val askNotifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) askNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent { MaterialTheme(colorScheme = darkColorScheme()) { DoorbellScreen() } }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "Doorbell", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun notifyRing() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Someone is at the door")
            .setContentText("Open the app to unlock or deny")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(this).notify(1, n)
    }

    @Composable
    fun DoorbellScreen() {
        var events by remember { mutableStateOf<List<DoorEvent>>(emptyList()) }
        var online by remember { mutableStateOf(false) }
        var lastNotified by remember { mutableIntStateOf(-1) }
        val scope = rememberCoroutineScope()

        // Poll the backend every 2.5 s
        LaunchedEffect(Unit) {
            while (true) {
                try {
                    val list = withContext(Dispatchers.IO) { ApiClient.getEvents() }
                    events = list
                    online = true
                    val pending = list.firstOrNull { it.type == "ring" && it.status == "pending" }
                    if (pending != null && pending.id != lastNotified) {
                        lastNotified = pending.id
                        notifyRing()
                    }
                } catch (e: Exception) {
                    online = false
                }
                delay(2500)
            }
        }

        val pending = events.firstOrNull { it.type == "ring" && it.status == "pending" }

        Scaffold(topBar = {
            TopAppBar(title = { Text("🔔 Smart Doorbell") }, actions = {
                Text(
                    if (online) "online" else "offline",
                    color = if (online) Color(0xFF2FBF71) else Color(0xFFEF5350),
                    modifier = Modifier.padding(end = 16.dp)
                )
            })
        }) { pad ->
            Column(Modifier.padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

                if (pending != null) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0x33F5A524))) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Someone is at the door", style = MaterialTheme.typography.titleMedium)
                            Text(pending.ts, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { scope.launch(Dispatchers.IO) { ApiClient.respond(pending.id, "unlock") } },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2FBF71))
                                ) { Text("Unlock") }
                                Button(
                                    onClick = { scope.launch(Dispatchers.IO) { ApiClient.respond(pending.id, "deny") } },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF5350))
                                ) { Text("Deny") }
                            }
                        }
                    }
                }

                Text("Activity", style = MaterialTheme.typography.titleSmall)
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(events) { e ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(if (e.type == "motion") "👀" else "🔔", Modifier.padding(end = 12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(e.visitor ?: if (e.type == "motion") "Motion detected" else "Unknown visitor")
                                    Text(e.ts, style = MaterialTheme.typography.bodySmall)
                                }
                                Text(e.status.uppercase(), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}
