-- Smart Doorbell: SQLite schema
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS visitors (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT NOT NULL,
    relation  TEXT,                       -- family, friend, delivery...
    rfid_tag  TEXT UNIQUE,                -- optional tag for auto-recognition
    trusted   INTEGER NOT NULL DEFAULT 0  -- 1 = auto-unlock allowed
);

CREATE TABLE IF NOT EXISTS events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    device_id   TEXT NOT NULL,
    type        TEXT NOT NULL CHECK (type IN ('ring','motion','unlock','deny')),
    visitor_id  INTEGER REFERENCES visitors(id),
    status      TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','unlocked','denied','ignored')),
    message     TEXT                      -- reply shown/spoken at the door
);

CREATE TABLE IF NOT EXISTS commands (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id  TEXT NOT NULL,
    action     TEXT NOT NULL,             -- 'unlock'
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    delivered  INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts DESC);
CREATE INDEX IF NOT EXISTS idx_cmd_pending ON commands(device_id, delivered);

-- Demo data
INSERT OR IGNORE INTO visitors (id, name, relation, rfid_tag, trusted) VALUES
 (1, 'Mom',            'family',   'A1B2C3D4', 1),
 (2, 'Delivery Guy',   'delivery', NULL,       0),
 (3, 'Best Friend',    'friend',   'DEADBEEF', 1);

-- Useful analytics queries
-- Rings per day:
--   SELECT date(ts) AS day, COUNT(*) FROM events WHERE type='ring' GROUP BY day;
-- Busiest hour:
--   SELECT strftime('%H', ts) AS hr, COUNT(*) c FROM events GROUP BY hr ORDER BY c DESC LIMIT 1;
