"""Smart Doorbell backend (Flask + SQLite).

Run:  pip install -r requirements.txt && python app.py
Dashboard: http://<your-ip>:5000/
"""
import os
import sqlite3
from functools import wraps

from flask import Flask, g, jsonify, request, send_from_directory

BASE = os.path.dirname(os.path.abspath(__file__))
SCHEMA = os.path.join(BASE, "..", "database", "schema.sql")
DB_PATH = os.environ.get("DOORBELL_DB", os.path.join(BASE, "..", "database", "doorbell.db"))
API_KEY = os.environ.get("DOORBELL_API_KEY", "hackathon-secret")
WEB_DIR = os.path.join(BASE, "..", "web")

app = Flask(__name__, static_folder=None)


# ---------- database helpers ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    with open(SCHEMA, encoding="utf-8") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def rows(sql, args=()):
    return [dict(r) for r in db().execute(sql, args).fetchall()]


def one(sql, args=()):
    r = db().execute(sql, args).fetchone()
    return dict(r) if r else None


# ---------- auth ----------
def require_key(fn):
    @wraps(fn)
    def wrapper(*a, **kw):
        if request.headers.get("X-API-Key") != API_KEY:
            return jsonify(error="invalid or missing X-API-Key"), 401
        return fn(*a, **kw)
    return wrapper


# ---------- device endpoints (called by the ESP32) ----------
@app.post("/api/ring")
@require_key
def ring():
    data = request.get_json(silent=True) or {}
    device = data.get("device_id", "door-1")
    tag = data.get("rfid_tag")

    # Ignore double presses within ~2 seconds (timestamps have 1 s resolution)
    dup = one(
        "SELECT id FROM events WHERE device_id=? AND type='ring' "
        "AND ts >= datetime('now','localtime','-2 seconds')",
        (device,),
    )
    if dup:
        return jsonify(event_id=dup["id"], status="pending", duplicate=True)

    visitor = one("SELECT * FROM visitors WHERE rfid_tag=?", (tag,)) if tag else None
    status = "unlocked" if visitor and visitor["trusted"] else "pending"

    cur = db().execute(
        "INSERT INTO events (device_id, type, visitor_id, status) VALUES (?,?,?,?)",
        (device, "ring", visitor["id"] if visitor else None, status),
    )
    if status == "unlocked":
        db().execute(
            "INSERT INTO commands (device_id, action) VALUES (?, 'unlock')", (device,)
        )
    db().commit()
    return jsonify(
        event_id=cur.lastrowid,
        status=status,
        visitor=visitor["name"] if visitor else None,
    )


@app.post("/api/motion")
@require_key
def motion():
    device = (request.get_json(silent=True) or {}).get("device_id", "door-1")
    cur = db().execute(
        "INSERT INTO events (device_id, type, status) VALUES (?, 'motion', 'ignored')",
        (device,),
    )
    db().commit()
    return jsonify(event_id=cur.lastrowid)


@app.get("/api/commands/<device_id>")
@require_key
def poll_commands(device_id):
    pending = rows(
        "SELECT id, action FROM commands WHERE device_id=? AND delivered=0 ORDER BY id",
        (device_id,),
    )
    if pending:
        ids = [c["id"] for c in pending]
        db().execute(
            f"UPDATE commands SET delivered=1 WHERE id IN ({','.join('?' * len(ids))})", ids
        )
        db().commit()
    return jsonify(commands=[{"action": c["action"]} for c in pending])


# ---------- app / dashboard endpoints ----------
@app.get("/api/events")
@require_key
def list_events():
    limit = min(int(request.args.get("limit", 50)), 200)
    return jsonify(
        events=rows(
            """SELECT e.id, e.ts, e.device_id, e.type, e.status, e.message,
                      v.name AS visitor
               FROM events e LEFT JOIN visitors v ON v.id = e.visitor_id
               ORDER BY e.id DESC LIMIT ?""",
            (limit,),
        )
    )


@app.post("/api/events/<int:event_id>/respond")
@require_key
def respond(event_id):
    data = request.get_json(silent=True) or {}
    action = data.get("action")
    if action not in ("unlock", "deny"):
        return jsonify(error="action must be 'unlock' or 'deny'"), 400

    ev = one("SELECT * FROM events WHERE id=?", (event_id,))
    if not ev:
        return jsonify(error="event not found"), 404

    status = "unlocked" if action == "unlock" else "denied"
    db().execute(
        "UPDATE events SET status=?, message=? WHERE id=?",
        (status, data.get("message"), event_id),
    )
    db().execute(
        "INSERT INTO commands (device_id, action) VALUES (?, ?)", (ev["device_id"], action)
    )
    db().commit()
    return jsonify(ok=True, status=status)


@app.get("/api/visitors")
@require_key
def visitors():
    return jsonify(visitors=rows("SELECT id, name, relation, trusted FROM visitors"))


@app.get("/api/stats")
@require_key
def stats():
    per_day = rows(
        "SELECT date(ts) AS day, COUNT(*) AS rings FROM events "
        "WHERE type='ring' AND ts >= date('now','localtime','-6 days') "
        "GROUP BY day ORDER BY day"
    )
    busiest = one(
        "SELECT strftime('%H', ts) AS hour, COUNT(*) AS n FROM events "
        "WHERE type='ring' GROUP BY hour ORDER BY n DESC LIMIT 1"
    )
    totals = one(
        "SELECT SUM(type='ring') AS rings, SUM(type='motion') AS motions, "
        "SUM(status='unlocked') AS unlocks FROM events"
    )
    return jsonify(per_day=per_day, busiest_hour=busiest, totals=totals)


# ---------- dashboard ----------
@app.get("/")
def index():
    return send_from_directory(WEB_DIR, "index.html")


@app.get("/<path:name>")
def static_files(name):
    return send_from_directory(WEB_DIR, name)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
