"""Smoke test: simulates the ESP32 and the dashboard against a temp database.
Run from the backend folder:  python test_api.py
"""
import os
import tempfile

tmp = tempfile.mkdtemp()
os.environ["DOORBELL_DB"] = os.path.join(tmp, "test.db")

import app as doorbell  # noqa: E402

doorbell.init_db()
client = doorbell.app.test_client()
H = {"X-API-Key": doorbell.API_KEY}


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    assert cond, name


# auth
check("rejects missing key", client.get("/api/events").status_code == 401)

# unknown visitor rings -> pending
r = client.post("/api/ring", json={"device_id": "door-1"}, headers=H).get_json()
check("unknown visitor is pending", r["status"] == "pending")
eid = r["event_id"]

# double press is de-duplicated
r2 = client.post("/api/ring", json={"device_id": "door-1"}, headers=H).get_json()
check("double press deduplicated", r2.get("duplicate") is True)

# owner unlocks from dashboard
check("respond ok", client.post(f"/api/events/{eid}/respond", json={"action": "unlock"}, headers=H).status_code == 200)
check("bad action rejected", client.post(f"/api/events/{eid}/respond", json={"action": "x"}, headers=H).status_code == 400)

# device polls and gets exactly one unlock, then nothing
cmds = client.get("/api/commands/door-1", headers=H).get_json()["commands"]
check("device receives unlock", cmds == [{"action": "unlock"}])
check("command delivered once", client.get("/api/commands/door-1", headers=H).get_json()["commands"] == [])

# trusted RFID tag auto-unlocks
import time; time.sleep(3.1)
r3 = client.post("/api/ring", json={"device_id": "door-1", "rfid_tag": "A1B2C3D4"}, headers=H).get_json()
check("trusted tag auto-unlocks", r3["status"] == "unlocked" and r3["visitor"] == "Mom")
check("auto-unlock queued", client.get("/api/commands/door-1", headers=H).get_json()["commands"] == [{"action": "unlock"}])

# motion + stats + events
client.post("/api/motion", json={"device_id": "door-1"}, headers=H)
s = client.get("/api/stats", headers=H).get_json()
check("stats totals", s["totals"]["rings"] == 2 and s["totals"]["motions"] == 1)
check("events listed", len(client.get("/api/events", headers=H).get_json()["events"]) == 3)

# dashboard served
check("dashboard served", client.get("/").status_code == 200)
check("css served", client.get("/style.css").status_code == 200)
print("\nAll tests passed")
