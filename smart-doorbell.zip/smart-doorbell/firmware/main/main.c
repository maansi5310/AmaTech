/*
 * Smart Doorbell firmware - ESP32 (ESP-IDF, C)
 *
 * Hardware (change pins below if needed):
 *   Push button -> GPIO4  (other leg to GND, internal pull-up used)
 *   PIR sensor  -> GPIO27 (HC-SR501 OUT)
 *   Relay/lock  -> GPIO26 (active HIGH, drives door strike via relay module)
 *   Buzzer      -> GPIO25 (active buzzer)
 *   Status LED  -> GPIO2
 *
 * Build: idf.py set-target esp32 && idf.py build flash monitor
 */
#include <stdio.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/event_groups.h"

#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "driver/gpio.h"
#include "cJSON.h"

/* ---------- CONFIG: edit these ---------- */
#define WIFI_SSID        "YOUR_WIFI_NAME"
#define WIFI_PASS        "YOUR_WIFI_PASSWORD"
#define SERVER_URL       "http://192.168.1.50:5000"   /* PC running backend/app.py */
#define API_KEY          "hackathon-secret"
#define DEVICE_ID        "door-1"

#define PIN_BUTTON       GPIO_NUM_4
#define PIN_PIR          GPIO_NUM_27
#define PIN_RELAY        GPIO_NUM_26
#define PIN_BUZZER       GPIO_NUM_25
#define PIN_LED          GPIO_NUM_2

#define UNLOCK_MS        5000
#define MOTION_COOLDOWN_MS 30000
#define POLL_INTERVAL_MS 2000
/* ---------------------------------------- */

static const char *TAG = "doorbell";
static EventGroupHandle_t wifi_events;
#define WIFI_CONNECTED_BIT BIT0

/* ================= Wi-Fi ================= */
static void wifi_handler(void *arg, esp_event_base_t base, int32_t id, void *data)
{
    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_START) {
        esp_wifi_connect();
    } else if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        xEventGroupClearBits(wifi_events, WIFI_CONNECTED_BIT);
        ESP_LOGW(TAG, "Wi-Fi lost, reconnecting...");
        esp_wifi_connect();
    } else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        xEventGroupSetBits(wifi_events, WIFI_CONNECTED_BIT);
        ESP_LOGI(TAG, "Wi-Fi connected");
    }
}

static void wifi_init(void)
{
    wifi_events = xEventGroupCreate();
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, wifi_handler, NULL));
    ESP_ERROR_CHECK(esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, wifi_handler, NULL));

    wifi_config_t wc = { 0 };
    strncpy((char *)wc.sta.ssid, WIFI_SSID, sizeof(wc.sta.ssid) - 1);
    strncpy((char *)wc.sta.password, WIFI_PASS, sizeof(wc.sta.password) - 1);
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wc));
    ESP_ERROR_CHECK(esp_wifi_start());

    xEventGroupWaitBits(wifi_events, WIFI_CONNECTED_BIT, pdFALSE, pdTRUE, portMAX_DELAY);
}

/* ================= HTTP helper ================= */
typedef struct {
    char  *buf;
    size_t cap;
    size_t len;
} resp_t;

static esp_err_t http_evt(esp_http_client_event_t *evt)
{
    resp_t *r = (resp_t *)evt->user_data;
    if (evt->event_id == HTTP_EVENT_ON_DATA && r && r->buf) {
        size_t room = r->cap - r->len - 1;
        size_t n = evt->data_len < room ? evt->data_len : room;
        memcpy(r->buf + r->len, evt->data, n);
        r->len += n;
        r->buf[r->len] = '\0';
    }
    return ESP_OK;
}

/* Returns HTTP status code, or -1 on transport error. Response body goes to out. */
static int http_call(esp_http_client_method_t method, const char *path,
                     const char *body, char *out, size_t out_cap)
{
    char url[160];
    snprintf(url, sizeof(url), "%s%s", SERVER_URL, path);

    resp_t r = { .buf = out, .cap = out_cap, .len = 0 };
    if (out && out_cap) out[0] = '\0';

    esp_http_client_config_t cfg = {
        .url = url,
        .method = method,
        .timeout_ms = 5000,
        .event_handler = http_evt,
        .user_data = &r,
    };
    esp_http_client_handle_t c = esp_http_client_init(&cfg);
    esp_http_client_set_header(c, "X-API-Key", API_KEY);
    if (body) {
        esp_http_client_set_header(c, "Content-Type", "application/json");
        esp_http_client_set_post_field(c, body, strlen(body));
    }

    esp_err_t err = esp_http_client_perform(c);
    int status = (err == ESP_OK) ? esp_http_client_get_status_code(c) : -1;
    if (err != ESP_OK) ESP_LOGE(TAG, "HTTP %s failed: %s", path, esp_err_to_name(err));
    esp_http_client_cleanup(c);
    return status;
}

/* ================= Hardware ================= */
static void gpio_setup(void)
{
    gpio_config_t in = {
        .pin_bit_mask = (1ULL << PIN_BUTTON),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
    };
    gpio_config(&in);

    gpio_config_t pir = {
        .pin_bit_mask = (1ULL << PIN_PIR),
        .mode = GPIO_MODE_INPUT,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
    };
    gpio_config(&pir);

    gpio_config_t out = {
        .pin_bit_mask = (1ULL << PIN_RELAY) | (1ULL << PIN_BUZZER) | (1ULL << PIN_LED),
        .mode = GPIO_MODE_OUTPUT,
    };
    gpio_config(&out);
    gpio_set_level(PIN_RELAY, 0);
    gpio_set_level(PIN_BUZZER, 0);
    gpio_set_level(PIN_LED, 0);
}

static void beep(int times, int on_ms, int off_ms)
{
    for (int i = 0; i < times; i++) {
        gpio_set_level(PIN_BUZZER, 1);
        vTaskDelay(pdMS_TO_TICKS(on_ms));
        gpio_set_level(PIN_BUZZER, 0);
        vTaskDelay(pdMS_TO_TICKS(off_ms));
    }
}

static void unlock_door(void)
{
    ESP_LOGI(TAG, "UNLOCK");
    gpio_set_level(PIN_LED, 1);
    gpio_set_level(PIN_RELAY, 1);
    beep(1, 150, 0);
    vTaskDelay(pdMS_TO_TICKS(UNLOCK_MS));
    gpio_set_level(PIN_RELAY, 0);      /* auto re-lock */
    gpio_set_level(PIN_LED, 0);
}

/* RFID hook: wire up an MFRC522 here and return the tag as a hex string
 * (e.g. "A1B2C3D4"), or NULL when no card is present. */
static const char *read_rfid_tag(void)
{
    return NULL;
}

/* ================= Tasks ================= */
static void button_task(void *arg)
{
    int last = 1;
    for (;;) {
        int now = gpio_get_level(PIN_BUTTON);
        if (last == 1 && now == 0) {                /* falling edge = press */
            vTaskDelay(pdMS_TO_TICKS(30));          /* debounce */
            if (gpio_get_level(PIN_BUTTON) == 0) {
                ESP_LOGI(TAG, "Doorbell pressed");
                beep(2, 120, 80);                   /* ding-dong at the door */

                char body[96], resp[256];
                const char *tag = read_rfid_tag();
                if (tag)
                    snprintf(body, sizeof(body),
                             "{\"device_id\":\"%s\",\"rfid_tag\":\"%s\"}", DEVICE_ID, tag);
                else
                    snprintf(body, sizeof(body), "{\"device_id\":\"%s\"}", DEVICE_ID);

                int code = http_call(HTTP_METHOD_POST, "/api/ring", body, resp, sizeof(resp));
                if (code == 200) {
                    cJSON *j = cJSON_Parse(resp);
                    if (j) {
                        cJSON *st = cJSON_GetObjectItem(j, "status");
                        if (cJSON_IsString(st) && strcmp(st->valuestring, "unlocked") == 0)
                            unlock_door();          /* trusted visitor */
                        cJSON_Delete(j);
                    }
                }
                while (gpio_get_level(PIN_BUTTON) == 0)   /* wait for release */
                    vTaskDelay(pdMS_TO_TICKS(20));
            }
        }
        last = now;
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

static void motion_task(void *arg)
{
    int last = 0;
    for (;;) {
        int now = gpio_get_level(PIN_PIR);
        if (now == 1 && last == 0) {
            ESP_LOGI(TAG, "Motion detected");
            char body[64], resp[64];
            snprintf(body, sizeof(body), "{\"device_id\":\"%s\"}", DEVICE_ID);
            http_call(HTTP_METHOD_POST, "/api/motion", body, resp, sizeof(resp));
            vTaskDelay(pdMS_TO_TICKS(MOTION_COOLDOWN_MS));   /* don't spam the log */
        }
        last = now;
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

static void command_task(void *arg)
{
    char path[64], resp[256];
    snprintf(path, sizeof(path), "/api/commands/%s", DEVICE_ID);

    for (;;) {
        int code = http_call(HTTP_METHOD_GET, path, NULL, resp, sizeof(resp));
        if (code == 200) {
            cJSON *j = cJSON_Parse(resp);
            cJSON *arr = j ? cJSON_GetObjectItem(j, "commands") : NULL;
            cJSON *it = NULL;
            cJSON_ArrayForEach(it, arr) {
                cJSON *act = cJSON_GetObjectItem(it, "action");
                if (!cJSON_IsString(act)) continue;
                if (strcmp(act->valuestring, "unlock") == 0)      unlock_door();
                else if (strcmp(act->valuestring, "deny") == 0)   beep(3, 400, 150);
            }
            cJSON_Delete(j);
        }
        vTaskDelay(pdMS_TO_TICKS(POLL_INTERVAL_MS));
    }
}

/* ================= Entry ================= */
void app_main(void)
{
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }
    gpio_setup();
    wifi_init();
    beep(1, 100, 0);                       /* boot OK */

    xTaskCreate(button_task,  "button",  4096, NULL, 5, NULL);
    xTaskCreate(motion_task,  "motion",  4096, NULL, 4, NULL);
    xTaskCreate(command_task, "commands", 6144, NULL, 3, NULL);
}
